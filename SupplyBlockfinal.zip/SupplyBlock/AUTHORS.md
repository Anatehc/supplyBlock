# Authors ordered by first contribution

* Tom Zerucha <tz@execpc.com>
* Alasdair Mercer <mercer.alasdair@gmail.com>
* Alexandre Perrin <alex@kaworu.ch>
* Michael Mason
* Benjamin Besse <contact@throrinstudio.com>
* Marek Vavrecan <vavrecan@gmail.com>
